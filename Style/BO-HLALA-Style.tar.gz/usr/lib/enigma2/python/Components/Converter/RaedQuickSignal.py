#Developed By Bo.HLALA .. ^_^  ready to Lets Fun...  Lets Fun!!!
#Open Series ;(py2-py3)

#<widget source="session.CurrentService" render="Label" position="100,100" size="150,30" font="Regular;18" foregroundColor="white" backgroundColor="black" transparent="1">
#    <convert type="RaedQuickSignal">SNR_LABEL</convert>
#</widget>

#<widget source="session.CurrentService" render="Label" position="50,100" size="200,30" font="Regular;20" transparent="1">
#    <convert type="RaedQuickSignal">SNR_LABEL</convert>
#</widget>

#/usr/lib/enigma2/python/Components/Converter/RaedQuickSignal.py

#Restart Enigma2 GUI
#killall -9 enigma2

from Components.Converter.Converter import Converter
from Components.Element import cached
from time import time


class RaedQuickSignal(Converter):
    """
    Custom Enigma2 converter to display tuner signal and event information.

    Supported types:
        - SNR: Returns signal-to-noise ratio as percentage (string)
        - SNR_LABEL: Same as SNR, but prefixed with "SNR :"
        - AGC: Returns automatic gain control as percentage (string)
        - AGC_LABEL: Same as AGC, but prefixed with "AGC :"
        - BER: Returns bit error rate (string)
        - LOCK: Returns boolean indicating if tuner is locked
        - Event: Returns event progress percentage as integer string
        - Event_Percent: Returns event progress with "%" symbol
    """

    def __init__(self, type):
        Converter.__init__(self, type)
        self.type = type

    @cached
    def getText(self):
        # SNR
        if self.type in ("SNR", "SNR_LABEL"):
            snr = self.source.snr or 0
            percent = snr * 100 // 65536
            return f"SNR : {percent}%" if self.type == "SNR_LABEL" else str(percent)

        # AGC
        elif self.type in ("AGC", "AGC_LABEL"):
            agc = self.source.agc or 0
            percent = agc * 100 // 65536
            return f"AGC : {percent}%" if self.type == "AGC_LABEL" else str(percent)

        # BER
        elif self.type == "BER":
            ber = self.source.ber
            return str(ber or 0)

        # Event progress
        elif self.type in ("Event", "Event_Percent"):
            event = self.source.event
            if event:
                duration = event.getDuration()
                if duration > 0:
                    elapsed = int(time()) - event.getBeginTime()
                    progress = elapsed * 100 // duration
                    progress = max(0, min(progress, 100))  # Clamp between 0 and 100
                    return f"{progress}%" if self.type == "Event_Percent" else str(progress)
            return "0%" if self.type == "Event_Percent" else "0"

        # Default case
        return ""

    text = property(getText)

    @cached
    def getBool(self):
        # BER check
        if self.type == "BER":
            return bool(self.source.ber)

        # LOCK check
        elif self.type == "LOCK":
            return bool(self.source.lock)

        # Default
        return False

    boolean = property(getBool)
