from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, loadPNG
import os
import sys

class RaedQuickSignalAglareBoxImage(Renderer):
    GUI_WIDGET = ePixmap

    def __init__(self):
        Renderer.__init__(self)
        self.image_path = "/usr/share/enigma2/"
        self.filename = None
        self.full_path = None

    def applySkin(self, desktop, parent):
        attribs = self.skinAttributes or []
        for attribute in attribs:
            attr = attribute[0]
            value = attribute[1]
            if attr == "path":
                self.image_path = value
            elif attr == "filename":
                self.filename = value
        return Renderer.applySkin(self, desktop, parent)

    def changed(self, what):
        if not self.instance:
            return
        if what[0] != self.CHANGED_CLEAR:
            self.updateImage()

    def updateImage(self):
        hostname = "default"

        if self.filename:
            self.full_path = os.path.join(self.image_path, self.filename)
        else:
            try:
                with open("/etc/hostname", "r") as f:
                    hostname = f.read().strip()
            except Exception as e:
                self._log("Failed to read hostname: {}".format(e))

            self.full_path = os.path.join(self.image_path, "{}.png".format(hostname))

            # Fallback if file doesn't exist
            if not os.path.exists(self.full_path):
                self._log("Image not found for hostname '{}', falling back to default.".format(hostname))
                self.full_path = os.path.join(self.image_path, "default.png")

        if os.path.exists(self.full_path):
            try:
                pixmap = loadPNG(self.full_path)
                if pixmap:
                    self.instance.setPixmap(pixmap)
                    self.instance.show()
                    self._log("Image loaded successfully: {}".format(self.full_path))
                else:
                    self.instance.hide()
                    self._log("Failed to load image (possibly corrupted): {}".format(self.full_path))
            except Exception as e:
                self.instance.hide()
                self._log("Exception while loading image '{}': {}".format(self.full_path, e))
        else:
            self.instance.hide()
            self._log("Final image not found: {}".format(self.full_path))

    def onShow(self):
        self.updateImage()

    def onHide(self):
        self.instance.hide()

    def _log(self, message):
        try:
            log_path = "/tmp/aglareboximage.log"
            if sys.version_info[0] < 3:
                with open(log_path, "a") as f:
                    f.write("[AglareBoxImage] " + message + "\n")
            else:
                with open(log_path, "a", encoding="utf-8") as f:
                    f.write("[AglareBoxImage] " + message + "\n")
        except Exception:
            pass
